﻿namespace abdul_133
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Btnlogin = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BtnCombo = new System.Windows.Forms.Button();
            this.BtnChkBox = new System.Windows.Forms.Button();
            this.BtnRadio = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.BtnSelfieApp2 = new System.Windows.Forms.Button();
            this.BtnSelfieApp1 = new System.Windows.Forms.Button();
            this.BtnPicturebox2 = new System.Windows.Forms.Button();
            this.BtnPicturebox1 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.BtnRandomCom = new System.Windows.Forms.Button();
            this.BtnRandom = new System.Windows.Forms.Button();
            this.BtnTimer = new System.Windows.Forms.Button();
            this.Btnprogress = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnTalk = new System.Windows.Forms.Button();
            this.btnDraw = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.BtnJohari = new System.Windows.Forms.Button();
            this.btnABCAnalysis = new System.Windows.Forms.Button();
            this.btnRoboticCell = new System.Windows.Forms.Button();
            this.btnManufacturingCell = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.BtnArduino = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Btnlogin);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.username);
            this.groupBox1.Location = new System.Drawing.Point(25, 32);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(225, 143);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Login to IE322";
            // 
            // Btnlogin
            // 
            this.Btnlogin.Location = new System.Drawing.Point(92, 114);
            this.Btnlogin.Name = "Btnlogin";
            this.Btnlogin.Size = new System.Drawing.Size(75, 23);
            this.Btnlogin.TabIndex = 4;
            this.Btnlogin.Text = "login";
            this.Btnlogin.UseVisualStyleBackColor = true;
            this.Btnlogin.Click += new System.EventHandler(this.Btnlogin_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(92, 65);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(92, 35);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "password";
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.Location = new System.Drawing.Point(6, 35);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(71, 17);
            this.username.TabIndex = 0;
            this.username.Text = "username";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.BtnCombo);
            this.groupBox2.Controls.Add(this.BtnChkBox);
            this.groupBox2.Controls.Add(this.BtnRadio);
            this.groupBox2.Location = new System.Drawing.Point(299, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 100);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Basic Controls";
            // 
            // BtnCombo
            // 
            this.BtnCombo.Location = new System.Drawing.Point(57, 65);
            this.BtnCombo.Name = "BtnCombo";
            this.BtnCombo.Size = new System.Drawing.Size(75, 23);
            this.BtnCombo.TabIndex = 2;
            this.BtnCombo.Text = "Combo";
            this.BtnCombo.UseVisualStyleBackColor = true;
            this.BtnCombo.Click += new System.EventHandler(this.BtnCombo_Click);
            // 
            // BtnChkBox
            // 
            this.BtnChkBox.Location = new System.Drawing.Point(100, 29);
            this.BtnChkBox.Name = "BtnChkBox";
            this.BtnChkBox.Size = new System.Drawing.Size(84, 23);
            this.BtnChkBox.TabIndex = 1;
            this.BtnChkBox.Text = "CheckBox";
            this.BtnChkBox.UseVisualStyleBackColor = true;
            this.BtnChkBox.Click += new System.EventHandler(this.BtnChkBox_Click);
            // 
            // BtnRadio
            // 
            this.BtnRadio.Location = new System.Drawing.Point(6, 29);
            this.BtnRadio.Name = "BtnRadio";
            this.BtnRadio.Size = new System.Drawing.Size(75, 23);
            this.BtnRadio.TabIndex = 0;
            this.BtnRadio.Text = "Radio";
            this.BtnRadio.UseVisualStyleBackColor = true;
            this.BtnRadio.Click += new System.EventHandler(this.BtnRadio_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.BtnSelfieApp2);
            this.groupBox3.Controls.Add(this.BtnSelfieApp1);
            this.groupBox3.Controls.Add(this.BtnPicturebox2);
            this.groupBox3.Controls.Add(this.BtnPicturebox1);
            this.groupBox3.Location = new System.Drawing.Point(299, 143);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(226, 100);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Graphical";
            // 
            // BtnSelfieApp2
            // 
            this.BtnSelfieApp2.Location = new System.Drawing.Point(118, 71);
            this.BtnSelfieApp2.Name = "BtnSelfieApp2";
            this.BtnSelfieApp2.Size = new System.Drawing.Size(108, 23);
            this.BtnSelfieApp2.TabIndex = 3;
            this.BtnSelfieApp2.Text = "SelfieApp2";
            this.BtnSelfieApp2.UseVisualStyleBackColor = true;
            // 
            // BtnSelfieApp1
            // 
            this.BtnSelfieApp1.Location = new System.Drawing.Point(118, 32);
            this.BtnSelfieApp1.Name = "BtnSelfieApp1";
            this.BtnSelfieApp1.Size = new System.Drawing.Size(102, 23);
            this.BtnSelfieApp1.TabIndex = 2;
            this.BtnSelfieApp1.Text = "SelfieApp1";
            this.BtnSelfieApp1.UseVisualStyleBackColor = true;
            // 
            // BtnPicturebox2
            // 
            this.BtnPicturebox2.Location = new System.Drawing.Point(18, 71);
            this.BtnPicturebox2.Name = "BtnPicturebox2";
            this.BtnPicturebox2.Size = new System.Drawing.Size(94, 23);
            this.BtnPicturebox2.TabIndex = 1;
            this.BtnPicturebox2.Text = "Picturebox2";
            this.BtnPicturebox2.UseVisualStyleBackColor = true;
            // 
            // BtnPicturebox1
            // 
            this.BtnPicturebox1.Location = new System.Drawing.Point(18, 32);
            this.BtnPicturebox1.Name = "BtnPicturebox1";
            this.BtnPicturebox1.Size = new System.Drawing.Size(94, 23);
            this.BtnPicturebox1.TabIndex = 0;
            this.BtnPicturebox1.Text = "Picturebox1";
            this.BtnPicturebox1.UseVisualStyleBackColor = true;
            this.BtnPicturebox1.Click += new System.EventHandler(this.BtnPicturebox1_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.BtnRandomCom);
            this.groupBox4.Controls.Add(this.BtnRandom);
            this.groupBox4.Controls.Add(this.BtnTimer);
            this.groupBox4.Controls.Add(this.Btnprogress);
            this.groupBox4.Location = new System.Drawing.Point(305, 280);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(226, 114);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "More Controls";
            // 
            // BtnRandomCom
            // 
            this.BtnRandomCom.Location = new System.Drawing.Point(100, 66);
            this.BtnRandomCom.Name = "BtnRandomCom";
            this.BtnRandomCom.Size = new System.Drawing.Size(102, 23);
            this.BtnRandomCom.TabIndex = 3;
            this.BtnRandomCom.Text = "RandomCom";
            this.BtnRandomCom.UseVisualStyleBackColor = true;
            this.BtnRandomCom.Click += new System.EventHandler(this.BtnRandomCom_Click);
            // 
            // BtnRandom
            // 
            this.BtnRandom.Location = new System.Drawing.Point(11, 66);
            this.BtnRandom.Name = "BtnRandom";
            this.BtnRandom.Size = new System.Drawing.Size(75, 23);
            this.BtnRandom.TabIndex = 2;
            this.BtnRandom.Text = "Random";
            this.BtnRandom.UseVisualStyleBackColor = true;
            this.BtnRandom.Click += new System.EventHandler(this.BtnRandom_Click);
            // 
            // BtnTimer
            // 
            this.BtnTimer.Location = new System.Drawing.Point(100, 21);
            this.BtnTimer.Name = "BtnTimer";
            this.BtnTimer.Size = new System.Drawing.Size(102, 23);
            this.BtnTimer.TabIndex = 1;
            this.BtnTimer.Text = "Timer";
            this.BtnTimer.UseVisualStyleBackColor = true;
            // 
            // Btnprogress
            // 
            this.Btnprogress.Location = new System.Drawing.Point(11, 21);
            this.Btnprogress.Name = "Btnprogress";
            this.Btnprogress.Size = new System.Drawing.Size(75, 23);
            this.Btnprogress.TabIndex = 0;
            this.Btnprogress.Text = "progress";
            this.Btnprogress.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnTalk);
            this.groupBox5.Controls.Add(this.btnDraw);
            this.groupBox5.Location = new System.Drawing.Point(615, 32);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(200, 100);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Draw and Talk";
            // 
            // btnTalk
            // 
            this.btnTalk.Location = new System.Drawing.Point(109, 34);
            this.btnTalk.Name = "btnTalk";
            this.btnTalk.Size = new System.Drawing.Size(75, 23);
            this.btnTalk.TabIndex = 1;
            this.btnTalk.Text = "Talk";
            this.btnTalk.UseVisualStyleBackColor = true;
            // 
            // btnDraw
            // 
            this.btnDraw.Location = new System.Drawing.Point(6, 35);
            this.btnDraw.Name = "btnDraw";
            this.btnDraw.Size = new System.Drawing.Size(71, 23);
            this.btnDraw.TabIndex = 0;
            this.btnDraw.Text = "Draw";
            this.btnDraw.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.BtnJohari);
            this.groupBox6.Controls.Add(this.btnABCAnalysis);
            this.groupBox6.Controls.Add(this.btnRoboticCell);
            this.groupBox6.Controls.Add(this.btnManufacturingCell);
            this.groupBox6.Location = new System.Drawing.Point(615, 167);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(215, 250);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "ExamApps";
            this.groupBox6.Enter += new System.EventHandler(this.groupBox6_Enter);
            // 
            // BtnJohari
            // 
            this.BtnJohari.Location = new System.Drawing.Point(22, 143);
            this.BtnJohari.Name = "BtnJohari";
            this.BtnJohari.Size = new System.Drawing.Size(162, 23);
            this.BtnJohari.TabIndex = 3;
            this.BtnJohari.Text = "Johari";
            this.BtnJohari.UseVisualStyleBackColor = true;
            // 
            // btnABCAnalysis
            // 
            this.btnABCAnalysis.Location = new System.Drawing.Point(22, 113);
            this.btnABCAnalysis.Name = "btnABCAnalysis";
            this.btnABCAnalysis.Size = new System.Drawing.Size(162, 23);
            this.btnABCAnalysis.TabIndex = 2;
            this.btnABCAnalysis.Text = "ABC Analysis";
            this.btnABCAnalysis.UseVisualStyleBackColor = true;
            // 
            // btnRoboticCell
            // 
            this.btnRoboticCell.Location = new System.Drawing.Point(22, 83);
            this.btnRoboticCell.Name = "btnRoboticCell";
            this.btnRoboticCell.Size = new System.Drawing.Size(162, 23);
            this.btnRoboticCell.TabIndex = 1;
            this.btnRoboticCell.Text = "Robotic Cell";
            this.btnRoboticCell.UseVisualStyleBackColor = true;
            // 
            // btnManufacturingCell
            // 
            this.btnManufacturingCell.Location = new System.Drawing.Point(22, 53);
            this.btnManufacturingCell.Name = "btnManufacturingCell";
            this.btnManufacturingCell.Size = new System.Drawing.Size(162, 23);
            this.btnManufacturingCell.TabIndex = 0;
            this.btnManufacturingCell.Text = "Manufacturing Cell";
            this.btnManufacturingCell.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.BtnArduino);
            this.groupBox7.Location = new System.Drawing.Point(855, 32);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(200, 100);
            this.groupBox7.TabIndex = 6;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "More controller";
            // 
            // BtnArduino
            // 
            this.BtnArduino.Location = new System.Drawing.Point(18, 40);
            this.BtnArduino.Name = "BtnArduino";
            this.BtnArduino.Size = new System.Drawing.Size(150, 23);
            this.BtnArduino.TabIndex = 7;
            this.BtnArduino.Text = "Arduino";
            this.BtnArduino.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Red;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(11, 431);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(357, 72);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "E x i t";
            this.btnExit.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 509);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Btnlogin;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label username;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button BtnCombo;
        private System.Windows.Forms.Button BtnChkBox;
        private System.Windows.Forms.Button BtnRadio;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button BtnSelfieApp2;
        private System.Windows.Forms.Button BtnSelfieApp1;
        private System.Windows.Forms.Button BtnPicturebox2;
        private System.Windows.Forms.Button BtnPicturebox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button BtnRandomCom;
        private System.Windows.Forms.Button BtnRandom;
        private System.Windows.Forms.Button BtnTimer;
        private System.Windows.Forms.Button Btnprogress;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnTalk;
        private System.Windows.Forms.Button btnDraw;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnManufacturingCell;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button BtnJohari;
        private System.Windows.Forms.Button btnABCAnalysis;
        private System.Windows.Forms.Button btnRoboticCell;
        private System.Windows.Forms.Button BtnArduino;
        private System.Windows.Forms.Button btnExit;
    }
}

