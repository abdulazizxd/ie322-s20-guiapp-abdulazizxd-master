﻿namespace abdul_133
{
    partial class frmRadio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radioRed = new System.Windows.Forms.RadioButton();
            this.radioGreen = new System.Windows.Forms.RadioButton();
            this.radioBlue = new System.Windows.Forms.RadioButton();
            this.radioYellow = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioYellow2 = new System.Windows.Forms.RadioButton();
            this.radioBlue2 = new System.Windows.Forms.RadioButton();
            this.radioGreen2 = new System.Windows.Forms.RadioButton();
            this.radioRed2 = new System.Windows.Forms.RadioButton();
            this.btnReset = new System.Windows.Forms.Button();
            this.BtnBack = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // radioRed
            // 
            this.radioRed.AutoSize = true;
            this.radioRed.Location = new System.Drawing.Point(93, 116);
            this.radioRed.Name = "radioRed";
            this.radioRed.Size = new System.Drawing.Size(55, 21);
            this.radioRed.TabIndex = 0;
            this.radioRed.TabStop = true;
            this.radioRed.Text = "Red";
            this.radioRed.UseVisualStyleBackColor = true;
            this.radioRed.CheckedChanged += new System.EventHandler(this.radioRed_CheckedChanged);
            // 
            // radioGreen
            // 
            this.radioGreen.AutoSize = true;
            this.radioGreen.Location = new System.Drawing.Point(93, 167);
            this.radioGreen.Name = "radioGreen";
            this.radioGreen.Size = new System.Drawing.Size(69, 21);
            this.radioGreen.TabIndex = 1;
            this.radioGreen.TabStop = true;
            this.radioGreen.Text = "Green";
            this.radioGreen.UseVisualStyleBackColor = true;
            this.radioGreen.CheckedChanged += new System.EventHandler(this.radioGreen_CheckedChanged);
            // 
            // radioBlue
            // 
            this.radioBlue.AutoSize = true;
            this.radioBlue.Location = new System.Drawing.Point(93, 216);
            this.radioBlue.Name = "radioBlue";
            this.radioBlue.Size = new System.Drawing.Size(57, 21);
            this.radioBlue.TabIndex = 2;
            this.radioBlue.TabStop = true;
            this.radioBlue.Text = "Blue";
            this.radioBlue.UseVisualStyleBackColor = true;
            this.radioBlue.CheckedChanged += new System.EventHandler(this.radioBlue_CheckedChanged);
            // 
            // radioYellow
            // 
            this.radioYellow.AutoSize = true;
            this.radioYellow.Location = new System.Drawing.Point(93, 268);
            this.radioYellow.Name = "radioYellow";
            this.radioYellow.Size = new System.Drawing.Size(69, 21);
            this.radioYellow.TabIndex = 3;
            this.radioYellow.TabStop = true;
            this.radioYellow.Text = "Yellow";
            this.radioYellow.UseVisualStyleBackColor = true;
            this.radioYellow.CheckedChanged += new System.EventHandler(this.radioYellow_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioYellow2);
            this.groupBox1.Controls.Add(this.radioBlue2);
            this.groupBox1.Controls.Add(this.radioGreen2);
            this.groupBox1.Controls.Add(this.radioRed2);
            this.groupBox1.Location = new System.Drawing.Point(361, 116);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(169, 203);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Grouped radio buttons";
            // 
            // radioYellow2
            // 
            this.radioYellow2.AutoSize = true;
            this.radioYellow2.Location = new System.Drawing.Point(50, 169);
            this.radioYellow2.Name = "radioYellow2";
            this.radioYellow2.Size = new System.Drawing.Size(69, 21);
            this.radioYellow2.TabIndex = 7;
            this.radioYellow2.TabStop = true;
            this.radioYellow2.Text = "Yellow";
            this.radioYellow2.UseVisualStyleBackColor = true;
            this.radioYellow2.CheckedChanged += new System.EventHandler(this.radioYellow2_CheckedChanged);
            // 
            // radioBlue2
            // 
            this.radioBlue2.AutoSize = true;
            this.radioBlue2.Location = new System.Drawing.Point(50, 117);
            this.radioBlue2.Name = "radioBlue2";
            this.radioBlue2.Size = new System.Drawing.Size(57, 21);
            this.radioBlue2.TabIndex = 6;
            this.radioBlue2.TabStop = true;
            this.radioBlue2.Text = "Blue";
            this.radioBlue2.UseVisualStyleBackColor = true;
            this.radioBlue2.CheckedChanged += new System.EventHandler(this.radioBlue2_CheckedChanged);
            // 
            // radioGreen2
            // 
            this.radioGreen2.AutoSize = true;
            this.radioGreen2.Location = new System.Drawing.Point(50, 68);
            this.radioGreen2.Name = "radioGreen2";
            this.radioGreen2.Size = new System.Drawing.Size(69, 21);
            this.radioGreen2.TabIndex = 5;
            this.radioGreen2.TabStop = true;
            this.radioGreen2.Text = "Green";
            this.radioGreen2.UseVisualStyleBackColor = true;
            this.radioGreen2.CheckedChanged += new System.EventHandler(this.radioGreen2_CheckedChanged);
            // 
            // radioRed2
            // 
            this.radioRed2.AutoSize = true;
            this.radioRed2.Location = new System.Drawing.Point(50, 21);
            this.radioRed2.Name = "radioRed2";
            this.radioRed2.Size = new System.Drawing.Size(55, 21);
            this.radioRed2.TabIndex = 4;
            this.radioRed2.TabStop = true;
            this.radioRed2.Text = "Red";
            this.radioRed2.UseVisualStyleBackColor = true;
            this.radioRed2.CheckedChanged += new System.EventHandler(this.radioRed2_CheckedChanged);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(245, 41);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 5;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // BtnBack
            // 
            this.BtnBack.Location = new System.Drawing.Point(617, 362);
            this.BtnBack.Name = "BtnBack";
            this.BtnBack.Size = new System.Drawing.Size(75, 23);
            this.BtnBack.TabIndex = 6;
            this.BtnBack.Text = "Back";
            this.BtnBack.UseVisualStyleBackColor = true;
            this.BtnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // frmRadio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnBack);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.radioYellow);
            this.Controls.Add(this.radioBlue);
            this.Controls.Add(this.radioGreen);
            this.Controls.Add(this.radioRed);
            this.Name = "frmRadio";
            this.Text = "Radio Form";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioRed;
        private System.Windows.Forms.RadioButton radioGreen;
        private System.Windows.Forms.RadioButton radioBlue;
        private System.Windows.Forms.RadioButton radioYellow;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioYellow2;
        private System.Windows.Forms.RadioButton radioBlue2;
        private System.Windows.Forms.RadioButton radioGreen2;
        private System.Windows.Forms.RadioButton radioRed2;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button BtnBack;
    }
}